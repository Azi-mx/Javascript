let number = prompt("Enter a number if you want to check even or odd : ");
 (number%2==0) ? document.write("this number is even") : document.write("this number is odd");

 