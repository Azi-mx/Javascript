let number = prompt("Enter a number, you want to check positive, negative or zero : ");

if (number > 0) {

    document.write("Number is positive");

} else if (number < 0) {

    document.write("Number is negative");

} else {

    document.write("Number is zero");

}