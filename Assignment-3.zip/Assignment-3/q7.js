let val1 = prompt("Enter two Numbers if you want to check gretter than or less than :<br> Enter first no : ");
let val2 = prompt("Enter second no : ");

if (val1 == val2) {

    document.write("Both Number are Same");

} else if (val1 > val2) {

    document.write("First Number is gretter than second Number<br>");

    document.write("Second Number is less than first Number<br>");

} else {

    document.write("Second Number is gretter than first Number<br>");

    document.write("First Number is less than second Number<br>");
    
}

